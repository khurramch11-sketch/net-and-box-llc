import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Tv, Monitor, Settings, Zap, Check, Phone, Mail, MapPin, X, ArrowRight } from 'lucide-react';

export default function App() {
  const [legalView, setLegalView] = useState<string | null>(null);
  const [blogView, setBlogView] = useState<number | null>(null);

  const closeLegal = () => setLegalView(null);
  const closeBlog = () => setBlogView(null);

  return (
    <div id="website-root" className="min-h-screen bg-[#0a0a0a] font-sans text-white selection:bg-blue-500/30">
      <Navigation />
      <Hero />
      <ExperienceGallery />
      <TerritoryCheck />
      <ProcessSection />
      <Services />
      <BillingOptimization />
      <Pricing />
      <About />
      <TrustSection />
      <BlogSection onBlogClick={setBlogView} />
      <FAQ />
      <WriteForUsSection />
      <Contact />
      <Newsletter />
      <Footer onLegalClick={setLegalView} />

      <AnimatePresence>
        {legalView && (
          <LegalModal type={legalView} onClose={closeLegal} />
        )}
        {blogView !== null && (
          <BlogModal postId={blogView} onClose={closeBlog} />
        )}
      </AnimatePresence>
    </div>
  );
}

function BlogModal({ postId, onClose }: { postId: number; onClose: () => void }) {
  const posts = [
    {
      title: "The Future of Fiber Optics in 2024",
      date: "May 10, 2024",
      image: "https://images.unsplash.com/photo-1551703599-6b3e8379aa8b?q=80&w=1200&h=600&auto=format&fit=crop",
      body: `
        <div class="space-y-6 text-gray-400 text-sm leading-relaxed">
          <p>The telecommunications landscape is undergoing a radical shift as fiber optic infrastructure becomes the gold standard for both residential and commercial connectivity. In 2024, the push for multi-gigabit speeds is no longer a luxury but a necessity for the modern digital economy.</p>
          
          <h4 class="text-white font-bold text-lg">Why Fiber Wins</h4>
          <p>Unlike traditional copper-based systems, fiber optics utilize light to transmit data, resulting in virtually zero signal degradation over long distances. This means symmetrical upload and download speeds, which are critical for high-definition video conferencing, cloud computing, and real-time gaming.</p>

          <h4 class="text-white font-bold text-lg">The JNA Advantage</h4>
          <p>As a JNA Authorized Dealer, Net & Box LLC is at the forefront of this rollout. We provide structured technical audits to ensure that the fiber infrastructure being brought to your doorstep is optimized for your specific hardware ecosystem.</p>
        </div>
      `
    },
    {
      title: "Maximizing Your Home Entertainment Setup",
      date: "May 05, 2024",
      image: "https://images.unsplash.com/photo-1593359677771-482a0ca810e4?q=80&w=1200&h=600&auto=format&fit=crop",
      body: `
        <div class="space-y-6 text-gray-400 text-sm leading-relaxed">
          <p>Having a premium cable package is only half the battle. To truly experience cinema-quality entertainment at home, your hardware and signal distribution must be flawlessly synchronized.</p>
          
          <h4 class="text-white font-bold text-lg">Hardware Synchronization</h4>
          <p>Modern 4K UHD boxes require high-bandwidth HDMI interfaces and stable low-latency connections to prevent buffering or artifacts. Our technicians specialize in calibrating these devices to work harmoniously with your JNA authorized service lines.</p>

          <h4 class="text-white font-bold text-lg">Content Curation</h4>
          <p>We help families and businesses organize their channel lineups to prioritize the content that matters most—whether it's premium sports networks, international news, or 24/7 educational broadcasting.</p>
        </div>
      `
    },
    {
      title: "Why Cord-Cutting isn't the Only Answer",
      date: "April 28, 2024",
      image: "https://images.unsplash.com/photo-1522869635100-9f4c5e86aa37?q=80&w=1200&h=600&auto=format&fit=crop",
      body: `
        <div class="space-y-6 text-gray-400 text-sm leading-relaxed">
          <p>The "Cord-Cutting" trend has dominated headlines, but many consumers are discovering that managing ten different streaming subscriptions can be more expensive and frustrating than a single, high-quality cable bundle.</p>
          
          <h4 class="text-white font-bold text-lg">The Hybrid Value Proposition</h4>
          <p>The smartest consumers in 2024 are moving toward hybrid models. By bundling high-speed internet with a core cable package, you secure local news, live sports, and live events that streaming platforms often lack—all while keeping your monthly bill predictable.</p>

          <h4 class="text-white font-bold text-lg">Reliability Over "Good Enough"</h4>
          <p>Streaming relies entirely on your local network's real-time performance. Cable TV provides a dedicated, managed signal path that ensures your "big game" viewing isn't interrupted by a neighbor's heavy download usage.</p>
        </div>
      `
    }
  ];

  const post = posts[postId];
  if (!post) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[60] flex items-center justify-center p-4 md:p-12 bg-black/95 backdrop-blur-md"
      onClick={onClose}
    >
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 20, opacity: 0 }}
        className="w-full max-w-4xl bg-[#141414] border border-white/10 rounded-xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="relative h-48 md:h-80 shrink-0">
          <img src={post.image} alt={post.title} className="w-full h-full object-cover grayscale brightness-50" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#141414] to-transparent" />
          <button onClick={onClose} className="absolute top-6 right-6 h-10 w-10 bg-black/50 rounded-full flex items-center justify-center text-white hover:bg-white hover:text-black transition-all">
            <X size={20} />
          </button>
          <div className="absolute bottom-8 left-8 right-8">
            <div className="text-[10px] font-black text-blue-500 uppercase tracking-widest mb-2">{post.date}</div>
            <h3 className="text-3xl md:text-5xl font-light tracking-tight text-white">{post.title}</h3>
          </div>
        </div>
        <div className="p-8 md:p-12 overflow-y-auto" dangerouslySetInnerHTML={{ __html: post.body }} />
        <div className="p-6 border-t border-white/5 bg-[#0a0a0a] flex justify-between items-center">
          <div className="text-[10px] text-gray-500 uppercase tracking-widest font-black">Net & Box LLC | Authorized JNA Dealer</div>
          <button onClick={onClose} className="px-8 py-3 bg-white text-black text-[10px] font-black uppercase tracking-widest rounded hover:bg-blue-600 hover:text-white transition-all">Close Article</button>
        </div>
      </motion.div>
    </motion.div>
  );
}

function ProcessSection() {
  const steps = [
    { title: 'Check Coverage', desc: 'Verify your ZIP code against our nationwide JNA infrastructure map.' },
    { title: 'Select Bundle', desc: 'Choose from Fios, 5G Home, or Cable bundles optimized for your usage.' },
    { title: 'Certified Install', desc: 'Our authorized technicians deploy and synchronize your full viewing ecosystem.' }
  ];

  return (
    <section className="py-24 bg-[#0a0a0a] border-y border-white/5">
      <div className="mx-auto max-w-7xl px-6">
        <div className="grid gap-12 md:grid-cols-3">
          {steps.map((step, i) => (
            <div key={i} className="relative group">
              <div className="text-[80px] font-black text-white/5 absolute -top-12 -left-4 pointer-events-none group-hover:text-blue-500/10 transition-colors">0{i+1}</div>
              <h4 className="text-xl font-bold mb-4 relative z-10">{step.title}</h4>
              <p className="text-xs text-gray-500 leading-relaxed uppercase tracking-widest font-medium">{step.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function TrustSection() {
  return (
    <section className="py-24 bg-blue-600 relative overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        <div className="h-full w-full bg-[radial-gradient(#fff_1px,transparent_1px)] [background-size:20px_20px]" />
      </div>
      <div className="mx-auto max-w-7xl px-6 relative z-10">
        <div className="grid gap-12 lg:grid-cols-2 items-center">
          <div>
            <h2 className="text-xs font-black uppercase tracking-[0.3em] text-white/70 mb-6">Why Choose Us</h2>
            <h3 className="text-4xl md:text-5xl font-light tracking-tight text-white mb-8">The Professional <br /><span className="font-bold underline decoration-white/30">Standard</span> in Telecom</h3>
            <p className="text-white/80 text-sm md:text-base leading-relaxed mb-10 max-w-lg">
              As an Authorized Dealer, we don't just sell plans—we manage environments. Our team provides the bridge between giant telecom infrastructure and your specific living or working space.
            </p>
            <div className="flex gap-8">
              <div>
                <div className="text-4xl font-bold text-white mb-1">24/7</div>
                <div className="text-[10px] font-black text-white/60 uppercase tracking-widest">Tech Ops</div>
              </div>
              <div className="w-px h-12 bg-white/20" />
              <div>
                <div className="text-4xl font-bold text-white mb-1">100%</div>
                <div className="text-[10px] font-black text-white/60 uppercase tracking-widest">Authorized</div>
              </div>
            </div>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            {[
              { t: 'Secure Billing', d: 'All payments processed directly via provider secure gateways.' },
              { t: 'Expert Setup', d: 'Field technicians with JNA certification handles every wire.' },
              { t: 'No Hidden Fees', d: 'Transparent rate cards with primary provider accuracy.' },
              { t: 'Unified Support', d: 'One contact point for multiple provider management.' }
            ].map((item, i) => (
              <div key={i} className="bg-white/10 backdrop-blur-sm p-8 rounded-lg border border-white/10 hover:bg-white/20 transition-all">
                <h4 className="text-sm font-black uppercase text-white mb-3">{item.t}</h4>
                <p className="text-[10px] text-white/60 uppercase tracking-tighter leading-relaxed">{item.d}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function LegalModal({ type, onClose }: { type: string; onClose: () => void }) {
  const content = {
    privacy: {
      title: "Privacy Policy",
      body: `
        <div class="space-y-6 text-gray-400 text-sm leading-relaxed">
          <p>This Privacy Policy describes how Bill Payment Net and Box LLC ("we", "us", or "our") collects, uses, and shares your personal information when you use our services.</p>
          
          <section>
            <h4 class="text-white font-bold uppercase tracking-wider mb-2">1. Data Collection</h4>
            <p>We collect Personally Identifiable Information (PII) as part of our service provision. This may include your name, contact information, and service preferences. We obtain necessary consents in connection with the collection and use of this data.</p>
          </section>

          <section>
            <h4 class="text-white font-bold uppercase tracking-wider mb-2">2. Data Protection Requirements</h4>
            <p>Pursuant to our partnership agreements (including JNA Entertainment Specialists), we maintain strict measures to protect PII from unauthorized access, transmission, use, or disclosure. All stored PII is secured in physical or electronic environments compliant with industry standards.</p>
          </section>

          <section>
            <h4 class="text-white font-bold uppercase tracking-wider mb-2">3. Telemarketing Compliance</h4>
            <p>We strictly adhere to FTC/FCC National Do Not Call Lists and applicable State Do Not Call Lists. We do not make telephone solicitations to any number listed on these registries unless prior consent or an existing business relationship exists.</p>
          </section>

          <section>
            <h4 class="text-white font-bold uppercase tracking-wider mb-2">4. Restricted Access</h4>
            <p>Access to personal data is restricted to employees or subcontractors who have a specific "need to know" basis for providing services.</p>
          </section>
        </div>
      `
    },
    terms: {
      title: "Terms of Service",
      body: `
        <div class="space-y-6 text-gray-400 text-sm leading-relaxed">
          <p>By accessing or using our services, you agree to be bound by these Terms of Service.</p>

          <section>
            <h4 class="text-white font-bold uppercase tracking-wider mb-2">1. Service Scope</h4>
            <p>Bill Payment Net and Box LLC acts as an authorized agent/assignee for various TV and internet service providers. We provide consultation, setup guidance, and plan optimization services.</p>
          </section>

          <section>
            <h4 class="text-white font-bold uppercase tracking-wider mb-2">2. Agreement Term</h4>
            <p>Standard service agreements typically carry a one (1) year term and may automatically renew unless written notice of termination is provided. Termination without cause generally requires seven (7) days written notice.</p>
          </section>

          <section>
            <h4 class="text-white font-bold uppercase tracking-wider mb-2">3. Fees and Payments</h4>
            <p>All setup fees and initial CRM fees are non-refundable. Monthly service fees are determined based on the specific provider package selected by the user.</p>
          </section>

          <section>
            <h4 class="text-white font-bold uppercase tracking-wider mb-2">4. Liability</h4>
            <p>We bear liability for risks or damages resulting from the direct sale of services as outlined in our assignment agreements. However, we are not liable for indirect, exemplary, incidental, or consequential damages arising from service provider actions.</p>
          </section>

          <section>
            <h4 class="text-white font-bold uppercase tracking-wider mb-2">5. Governing Law</h4>
            <p>These terms shall be governed by and construed in accordance with the laws of the State of Florida/California, without regard to conflict of law principles.</p>
          </section>
        </div>
      `
    },
    refund: {
      title: "Refund Policy",
      body: `
        <div class="space-y-6 text-gray-400 text-sm leading-relaxed">
          <p>Our Refund Policy is designed to be transparent regarding service fees and setup costs.</p>

          <section>
            <h4 class="text-white font-bold uppercase tracking-wider mb-2">1. Non-Refundable Fees</h4>
            <p>The initial setup fee for the Client Relationship Manager (CRM) and any associated non-refundable setup fees (standardly $100.00 USD) are strictly non-refundable once the grant of rights or service setup has commenced.</p>
          </section>

          <section>
            <h4 class="text-white font-bold uppercase tracking-wider mb-2">2. Service Provider Billing</h4>
            <p>Refunds for monthly service packages are subject to the policies of the specific service provider (e.g., Spectrum, AT&T, Cox). We assist in navigating these providers' refund processes but do not directly issue refunds for their billed services.</p>
          </section>

          <section>
            <h4 class="text-white font-bold uppercase tracking-wider mb-2">3. Chargebacks</h4>
            <p>We monitor chargebacks over a 6-month to 1-year period (depending on the provider). Unauthorized chargebacks may result in immediate termination of service rights and potential legal action to recover outstanding balances.</p>
          </section>
        </div>
      `
    }
  }[type as keyof typeof content];

  if (!content) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[60] flex items-center justify-center p-6 bg-black/90 backdrop-blur-sm"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        className="w-full max-w-2xl bg-[#141414] border border-white/10 rounded-lg overflow-hidden shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b border-white/5 p-6 bg-[#1a1a1a]">
          <h3 className="text-xl font-light tracking-tight">{content.title}</h3>
          <button 
            onClick={onClose}
            className="text-gray-500 hover:text-white transition-colors"
          >
            <X size={20} />
          </button>
        </div>
        <div 
          className="p-8 max-h-[70vh] overflow-y-auto"
          dangerouslySetInnerHTML={{ __html: content.body }}
        />
        <div className="border-t border-white/5 p-6 bg-[#0a0a0a] flex justify-end">
          <button 
            onClick={onClose}
            className="px-6 py-2 bg-white text-black font-black uppercase text-[10px] tracking-widest rounded hover:bg-blue-500 hover:text-white transition-all"
          >
            Acknowledge
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

function Navigation() {
  return (
    <nav id="main-nav" className="fixed top-0 z-50 w-full border-b border-white/5 bg-[#0a0a0a]/80 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded bg-blue-600 text-white shadow-lg shadow-blue-900/40">
            <Tv size={24} />
          </div>
          <div className="flex flex-col">
            <span className="text-lg font-bold tracking-tight leading-none">
              NET & BOX <span className="text-blue-500">LLC</span>
            </span>
            <span className="text-[8px] font-black uppercase tracking-[0.2em] text-gray-500 mt-1">
              JNA Authorized Dealer
            </span>
          </div>
        </div>
        <div className="hidden gap-8 md:flex">
          {['Services', 'Packages', 'About', 'Blog', 'Contact'].map((item) => (
            <a
              key={item}
              id={`nav-link-${item.toLowerCase()}`}
              href={`#${item.toLowerCase()}`}
              className="text-xs font-bold uppercase tracking-widest text-gray-400 transition-colors hover:text-white"
            >
              {item}
            </a>
          ))}
        </div>
        <a
          id="nav-cta"
          href="tel:8884092279"
          className="rounded bg-white px-5 py-2 text-xs font-black uppercase tracking-widest text-black transition-all hover:bg-blue-500 hover:text-white active:scale-95"
        >
          (888) 409-2279
        </a>
      </div>
    </nav>
  );
}

function Hero() {
  return (
    <section id="hero" className="relative pt-32 pb-20 md:pt-48 md:pb-32 overflow-hidden border-b border-white/5">
      <div className="absolute inset-0 -z-10 opacity-20">
        <div className="absolute top-0 right-0 h-[500px] w-[500px] rounded-full bg-blue-600/30 blur-[120px]" />
        <div className="absolute bottom-0 left-0 h-[500px] w-[500px] rounded-full bg-indigo-600/20 blur-[120px]" />
      </div>
      
      <div className="mx-auto max-w-7xl px-6">
        <div className="grid gap-12 lg:grid-cols-2 lg:items-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center gap-2 rounded bg-blue-600 px-3 py-1 text-[10px] font-black tracking-widest text-white uppercase mb-6">
              JNA Authorized Reseller
            </div>
            <h1 className="text-5xl font-light leading-[1.1] tracking-tight text-white md:text-7xl mb-6">
              Premium Cable TV <br />
              <span className="text-blue-500 italic-serif-header">& Internet Solutions</span>
            </h1>
            <p className="text-sm text-gray-400 md:text-base leading-relaxed mb-8 max-w-xl">
              As a premier JNA Authorized Dealer, Net & Box LLC provides high-performance TV cable and high-speed broadband services. We specialize in structured installations and optimized viewing packages for residential and commercial excellence.
            </p>
            <div className="flex flex-wrap gap-4">
              <a
                id="hero-primary-cta"
                href="#packages"
                className="rounded bg-white px-8 py-4 text-xs font-black uppercase tracking-widest text-black transition-all hover:bg-blue-500 hover:text-white"
              >
                Explore Rate Bundles
              </a>
              <a
                id="hero-secondary-cta"
                href="tel:8884092279"
                className="rounded border border-white/10 bg-[#141414] px-8 py-4 text-xs font-black uppercase tracking-widest transition-all hover:border-white/30"
              >
                Consult a Specialist
              </a>
            </div>
          </motion.div>
          
          <motion.div
            id="hero-image-container"
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="aspect-[16/10] overflow-hidden rounded-lg border border-white/10 bg-[#141414] shadow-2xl">
              <img
                src="https://picsum.photos/seed/cinema-ultra-hd/1200/800"
                alt="Professional TV setup"
                className="h-full w-full object-cover opacity-90 transition-transform duration-1000 hover:scale-105"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="absolute -bottom-6 -left-6 border border-white/10 rounded bg-[#1a1a1a] p-6 text-white shadow-xl hidden md:block backdrop-blur-md">
              <div className="text-3xl font-light text-blue-500 mb-1">100%</div>
              <div className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Signal Reliability</div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function ExperienceGallery() {
  const images = [
    { seed: 'sports-field', title: 'Live Sports', tag: 'Ultra HD' },
    { seed: 'movie-theatre', title: 'Cinematic Movies', tag: 'Premium' },
    { seed: 'family-home', title: 'Family Viewing', tag: 'Safe' },
    { seed: 'coding-tech', title: 'Advanced Tech', tag: 'Reliable' },
  ];

  return (
    <section className="py-24 border-t border-white/5 bg-[#0a0a0a]">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mb-12">
          <h2 className="text-xs font-black uppercase tracking-[0.3em] text-blue-500 mb-4 font-sans">The Experience</h2>
          <h3 className="text-3xl font-light tracking-tight">Crystal Clear <span className="italic-serif-header">Entertainment</span></h3>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {images.map((img, idx) => (
            <motion.div 
              key={img.seed}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="group relative overflow-hidden rounded-lg aspect-[4/5] bg-[#141414]"
            >
              <img 
                src={`https://picsum.photos/seed/${img.seed}/600/800`}
                className="w-full h-full object-cover opacity-60 transition-all duration-700 group-hover:scale-110 group-hover:opacity-100"
                alt={img.title}
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-60 group-hover:opacity-100 transition-opacity" />
              <div className="absolute bottom-4 left-4">
                <div className="text-[8px] font-black uppercase bg-blue-600 text-white px-1.5 py-0.5 rounded mb-1 inline-block tracking-widest">{img.tag}</div>
                <div className="text-xs font-bold uppercase tracking-widest text-white">{img.title}</div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Services() {
  const services = [
    {
      id: 'service-new',
      title: 'Broadband Installation',
      desc: 'Expert deployment of high-speed internet and TV lines with technical requirements analysis.',
      count: '1',
    },
    {
      id: 'service-channel',
      title: 'Content Curation',
      desc: 'Customized channel lineups including Premium Sports, Cinema, and Local News broadcasting.',
      count: '2',
    },
    {
      id: 'service-setup',
      title: 'Infrastructure Support',
      desc: 'Advanced device synchronization and hardware setup for maximum signal reliability.',
      count: '3',
    },
    {
      id: 'service-upgrade',
      title: 'Enterprise Scalability',
      desc: 'Tiered plan audits and performance optimization for growing home and office needs.',
      count: '4',
    },
  ];

  return (
    <section id="services" className="py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mb-16">
          <h2 className="text-xs font-black uppercase tracking-[0.3em] text-blue-500 mb-4">Functional Scope</h2>
          <h3 className="text-3xl font-light tracking-tight md:text-5xl">Our TV Cable Services</h3>
        </div>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {services.map((service, idx) => (
            <motion.div
              key={service.id}
              id={service.id}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="group flex flex-col items-start rounded-lg border border-white/5 bg-[#141414] p-8 transition-colors hover:border-blue-500/50"
            >
              <div className="mb-6 h-12 w-12 rounded-full bg-white/5 flex items-center justify-center text-blue-500 font-bold text-lg border border-white/5">
                {service.count}
              </div>
              <h3 className="text-sm font-black uppercase tracking-widest text-white mb-3">{service.title}</h3>
              <p className="text-gray-500 leading-relaxed text-xs">{service.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function BillingOptimization() {
  const strategies = [
    { 
      t: 'Rate Schedule Analysis', 
      d: 'We deep-dive into complex provider rate cards to identify grandfathered pricing and hidden bundle opportunities.' 
    },
    { 
      t: 'Channel Portfolio Management', 
      d: 'Precision curation of channel settings to eliminate "ghost tiers" and unused premium addons that bloat monthly costs.' 
    },
    { 
      t: 'Agreement Compliance', 
      d: 'Every reduction strategy is implemented within the strict framework of provider service agreements for total legitimacy.' 
    }
  ];

  return (
    <section className="py-24 bg-[#0a0a0a] border-t border-white/5 relative overflow-hidden">
      <div className="mx-auto max-w-7xl px-6">
        <div className="grid gap-16 lg:grid-cols-2 items-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="order-2 lg:order-1"
          >
            <div className="relative aspect-video rounded-xl overflow-hidden border border-white/10 group">
              <img 
                src="https://images.unsplash.com/photo-1554224155-6726b3ff858f?q=80&w=1200&h=800&auto=format&fit=crop" 
                alt="Financial billing optimization" 
                className="w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-transparent" />
            </div>
          </motion.div>
          
          <div className="order-1 lg:order-2">
            <h2 className="text-xs font-black uppercase tracking-[0.3em] text-blue-500 mb-6 font-sans">Financial Strategy</h2>
            <h3 className="text-3xl md:text-5xl font-light tracking-tight text-white mb-8">Tension With <span className="italic-serif-header">High Billing?</span></h3>
            <p className="text-sm text-gray-400 leading-relaxed mb-8">
              Escalating telecom costs can create significant operational tension. As JNA Authorized Experts, we specialize in high-level billing management strategies designed to lower your monthly overhead. 
            </p>
            <p className="text-sm text-gray-400 leading-relaxed mb-10">
              Through precision channel setting management and expert rate audits, we advise customers on legitimate methods to reduce billing—strictly following all provider agreement policies to ensure secure, sustainable savings.
            </p>
            
            <div className="space-y-6">
              {strategies.map((s, i) => (
                <div key={i} className="flex gap-6 p-6 bg-[#141414] border border-white/5 rounded-lg hover:border-blue-500/30 transition-colors">
                  <div className="h-10 w-10 shrink-0 bg-blue-600/10 text-blue-500 flex items-center justify-center rounded font-sans font-black text-xs">
                    0{i+1}
                  </div>
                  <div>
                    <h4 className="text-xs font-black uppercase text-white mb-2 tracking-widest">{s.t}</h4>
                    <p className="text-[10px] text-gray-500 uppercase leading-relaxed font-bold">{s.d}</p>
                  </div>
                </div>
              ))}
            </div>
            
            <a href="#contact" className="mt-12 group inline-flex items-center gap-4 text-xs font-black uppercase tracking-[0.2em] text-white hover:text-blue-500 transition-colors">
              Request a Billing Audit <ArrowRight size={16} className="group-hover:translate-x-2 transition-transform" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

function Pricing() {
  const [activeTab, setActiveTab] = React.useState('Spectrum');

  const providerData: Record<string, any> = {
    'Spectrum': {
      tag: 'Broadband & Mobile',
      rates: [
        { name: 'Standard Internet', price: '$80' },
        { name: 'Ultra Internet', price: '$110' },
        { name: 'Gigabit Internet', price: '$180' },
        { name: 'Mobile Plan', price: '$70' },
        { name: 'TV Select Plan', price: '$20' }
      ]
    },
    'JNA Mobility': {
      tag: 'Wireless Services',
      rates: [
        { name: 'Unlimited Starter (1GB)', price: '$45' },
        { name: 'Unlimited Plus (5GB)', price: '$55' },
        { name: 'Unlimited Pro (10GB)', price: '$60' },
        { name: 'Unlimited Ultra (15GB)', price: '$63' }
      ]
    },
    'Xfinity': {
      tag: 'Comcast Cable',
      rates: [
        { name: 'Blast! Internet', price: '$50' },
        { name: 'Performance Pro', price: '$30' },
        { name: 'Premier TV Package', price: '$65' },
        { name: 'Preferred Plus TV', price: '$55' }
      ]
    },
    'AT&T & DTV': {
      tag: 'U-Verse & DirectTV',
      rates: [
        { name: 'U200 TV Package', price: '$65' },
        { name: 'AT&T Uverse TV', price: '$130' },
        { name: 'Internet (25-99 MB)', price: '$150' },
        { name: 'Internet (100 MB+)', price: '$100' },
        { name: 'DTV Premium', price: '$140' }
      ]
    },
    'Vivint': {
      tag: 'Smart Home Security',
      rates: [
        { name: 'Starter Kit Plan', price: '$1799' },
        { name: 'Monthly Monitoring', price: '$19.99+' },
        { name: 'Smart Home Video', price: '$44.99' },
        { name: 'Security Complete', price: '$69.99' }
      ]
    },
    'Verizon': {
      tag: 'Fios & 5G Home',
      rates: [
        { name: 'Fios 300 Mbps', price: '$49.99' },
        { name: 'Fios 500 Mbps', price: '$69.99' },
        { name: 'Fios 1 Gig', price: '$89.99' },
        { name: '5G Home Internet', price: '$35' },
        { name: 'Unlimited Welcome', price: '$65' }
      ]
    },
    'Frontier': {
      tag: 'Fiber Optic',
      rates: [
        { name: 'FiberOptic 500M', price: '$70' },
        { name: 'FiberOptic 1G', price: '$90' },
        { name: 'Video Services', price: '$18' },
        { name: 'Unlimited Voice', price: '$75' }
      ]
    }
  };

  const otherProviders = [
    'Buckeye', 'CenturyLink', 'COX', 'Hughesnet', 'Mediacom', 'Metronet', 
    'Astound', 'Rise', 'SmithVille', 'Bend', 'Hawaiian Telecom', 'Ziply', 
    'TDS', 'Windstream', 'WOW', 'Altice', 'Viasat'
  ];

  return (
    <section id="packages" className="py-24 md:py-32 border-t border-white/5">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mb-16">
          <h2 className="text-xs font-black uppercase tracking-[0.3em] text-blue-500 mb-4">Rate Schedules</h2>
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <h3 className="text-3xl font-light tracking-tight md:text-5xl">Provider Rate Explorer</h3>
            <div className="text-[10px] uppercase font-bold text-gray-500 tracking-widest border border-white/10 px-3 py-1 rounded">
              Effective 2026/2027 Rates
            </div>
          </div>
        </div>

        <div className="grid gap-8 lg:grid-cols-12">
          <div className="lg:col-span-3 space-y-1">
            <div className="text-[10px] font-black uppercase tracking-widest text-gray-600 mb-4 px-2">Major Providers</div>
            {Object.keys(providerData).map(name => (
              <button
                key={name}
                onClick={() => setActiveTab(name)}
                className={`w-full text-left px-4 py-3 rounded text-xs font-bold uppercase tracking-widest transition-all ${
                  activeTab === name 
                    ? 'bg-blue-600 text-white' 
                    : 'text-gray-500 hover:text-white hover:bg-white/5'
                }`}
              >
                {name}
              </button>
            ))}
            <div className="pt-8 text-[10px] font-black uppercase tracking-widest text-gray-600 mb-4 px-2">Other Partners</div>
            <div className="grid grid-cols-2 gap-1 lg:grid-cols-1">
              {otherProviders.map(p => (
                <div key={p} className="text-[10px] text-gray-500 py-1 px-2 border border-transparent">
                  • {p}
                </div>
              ))}
            </div>
          </div>

          <div className="lg:col-span-9">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-[#141414] border border-white/10 rounded-lg p-8 md:p-12 relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 opacity-5 -mr-20 -mt-20">
                <Tv size={300} />
              </div>
              
              <div className="relative">
                <div className="flex items-center gap-3 mb-8">
                  <div className="h-1 w-12 bg-blue-600"></div>
                  <div className="text-xs font-black uppercase tracking-[0.2em] text-blue-500">
                    {providerData[activeTab].tag}
                  </div>
                </div>
                
                <h4 className="text-4xl font-light mb-12">{activeTab} <span className="italic-serif-header">Offerings</span></h4>
                
                <div className="grid gap-4">
                  {providerData[activeTab].rates.map((rate: any, i: number) => (
                    <div 
                      key={i}
                      className="flex items-center justify-between py-4 border-b border-white/5 group hover:border-blue-500/30 transition-colors"
                    >
                      <div className="text-sm font-bold uppercase tracking-widest text-gray-300 group-hover:text-white">
                        {rate.name}
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-2xl font-light text-blue-500">{rate.price}</div>
                        <div className="text-[10px] font-black bg-white/5 px-2 py-1 rounded text-gray-500">MONTHLY</div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-16 flex flex-col md:flex-row items-center justify-between gap-6 bg-[#0a0a0a] p-8 rounded border border-white/5">
                  <div>
                    <div className="text-xs font-black uppercase text-white mb-1">Custom Configuration?</div>
                    <p className="text-xs text-gray-500 uppercase tracking-tighter">We assist with specific channel audits and setup requirements.</p>
                  </div>
                  <a
                    href="tel:8884092279"
                    className="whitespace-nowrap px-8 py-4 bg-white text-black font-black uppercase text-xs tracking-widest hover:bg-blue-500 hover:text-white transition-all rounded"
                  >
                    Negotiate Rate
                  </a>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}

function About() {
  return (
    <section id="about" className="py-24 md:py-32 bg-[#141414] border-y border-white/5 overflow-hidden">
      <div className="mx-auto max-w-7xl px-6">
        <div className="grid gap-16 lg:grid-cols-12 lg:items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="lg:col-span-7"
          >
            <h2 className="text-xs font-black uppercase tracking-[0.3em] text-blue-500 mb-6 font-sans">Strategic Partnership</h2>
            <h3 className="text-3xl font-light tracking-tight md:text-5xl mb-8">Authorized JNA Resident <span className="italic-serif-header">Telecom Dealer</span></h3>
            <p className="text-sm text-gray-400 leading-relaxed mb-6">
              Bill Payment Net and Box LLC serves as a premier JNA Reseller and Authorized Dealer. While headquartered in Riverside, California, we are fully authorized to provide high-performance TV cable services and high-speed broadband infrastructures across all 50 states.
            </p>
            <p className="text-sm text-gray-500 italic mb-10">
              "As an authorized dealer by JNA to sell these services, we aim to ensure every user understands their options and can manage their viewing experience effectively."
            </p>
            
            <div className="grid gap-4 grid-cols-2 text-right md:text-left">
              {[
                { label: 'JNA Certified', val: 'DEALER' },
                { label: 'Network Uptime', val: '99.9%' },
                { label: 'Fast Deployment', val: 'PRIORITY' },
                { label: 'Nationwide Support', val: '50 STATES' },
              ].map((stat, idx) => (
                <div key={stat.label} className="border border-white/5 bg-[#0a0a0a] p-6 rounded transition-colors hover:border-blue-500/30">
                  <div className="text-2xl font-light text-blue-500 mb-1">{stat.val}</div>
                  <div className="text-[10px] uppercase font-black tracking-widest text-gray-600">{stat.label}</div>
                </div>
              ))}
            </div>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="lg:col-span-5 relative"
          >
            <div className="aspect-square overflow-hidden rounded-2xl border border-white/10 grayscale hover:grayscale-0 transition-all duration-700">
              <img 
                src="https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=800&h=800&auto=format&fit=crop" 
                alt="Nationwide Communications Network" 
                className="w-full h-full object-cover opacity-70"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="absolute -top-4 -right-4 h-24 w-24 rounded-full bg-blue-600 flex items-center justify-center text-white font-black text-xs uppercase tracking-tighter text-center leading-none p-4 shadow-2xl animate-pulse">
              50 States Authorized
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function TerritoryCheck() {
  return (
    <section className="py-20 bg-[#1a1a1a] border-y border-white/5 overflow-hidden">
      <div className="mx-auto max-w-7xl px-6">
        <div className="bg-blue-600 rounded-lg p-8 md:p-16 flex flex-col md:flex-row items-center justify-between gap-12 relative">
          <div className="absolute right-0 top-0 opacity-10 -mr-10 -mt-10 pointer-events-none">
            <Monitor size={300} />
          </div>
          <div className="relative z-10 max-w-2xl">
            <h3 className="text-xs font-black uppercase tracking-[0.3em] text-white/70 mb-4">Nationwide Availability</h3>
            <h4 className="text-3xl md:text-5xl font-light tracking-tight text-white mb-6">Serviceable in <span className="font-bold underline decoration-white/30">All 50 States</span></h4>
            <p className="text-white/80 text-sm md:text-base leading-relaxed uppercase font-medium tracking-tight">
              As a premier JNA Authorized Dealer, we are fully licensed and authorized to sell and manage TV cable and broadband services in every state across the United States. Connect with us to verify local provider availability in your specific area.
            </p>
          </div>
          <div className="relative z-10 shrink-0">
            <a 
              href="#contact" 
              className="bg-white text-black px-10 py-5 rounded text-xs font-black uppercase tracking-widest hover:bg-black hover:text-white transition-all shadow-2xl"
            >
              Verify My ZIP Code
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

function BlogSection({ onBlogClick }: { onBlogClick: (id: number) => void }) {
  const posts = [
    {
      title: "The Future of Fiber Optics in 2024",
      excerpt: "Explore how multi-gigabit fiber infrastructure is revolutionizing presidential and commercial connectivity across the US.",
      date: "May 10, 2024",
      image: "https://images.unsplash.com/photo-1551703599-6b3e8379aa8b?q=80&w=800&h=600&auto=format&fit=crop"
    },
    {
      title: "Maximizing Your Home Entertainment Setup",
      excerpt: "An expert audit on combining 4K hardware with premium JNA authorized cable packages for the ultimate cinema experience.",
      date: "May 05, 2024",
      image: "https://images.unsplash.com/photo-1593359677771-482a0ca810e4?q=80&w=800&h=600&auto=format&fit=crop"
    },
    {
      title: "Why Cord-Cutting isn't the Only Answer",
      excerpt: "Analyzing the value proposition of hybrid cable-streaming bundles vs. standalone internet subscriptions in the current market.",
      date: "April 28, 2024",
      image: "https://images.unsplash.com/photo-1522869635100-9f4c5e86aa37?q=80&w=800&h=600&auto=format&fit=crop"
    }
  ];

  return (
    <section id="blog" className="py-24 bg-[#0a0a0a] border-t border-white/5">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mb-16">
          <h2 className="text-xs font-black uppercase tracking-[0.3em] text-blue-500 mb-4">Telecom Insights</h2>
          <h3 className="text-3xl font-light tracking-tight md:text-5xl">Industry <span className="italic-serif-header">Knowledge Base</span></h3>
        </div>
        <div className="grid gap-8 md:grid-cols-3">
          {posts.map((post, i) => (
            <motion.article 
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="group cursor-pointer"
              onClick={() => onBlogClick(i)}
            >
              <div className="aspect-[4/3] overflow-hidden rounded-lg mb-6 border border-white/10">
                <img 
                  src={post.image} 
                  alt={post.title} 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 opacity-80"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="text-[10px] font-black text-blue-500 uppercase tracking-widest mb-2">{post.date}</div>
              <h4 className="text-lg font-bold text-white mb-3 group-hover:text-blue-500 transition-colors uppercase tracking-tight leading-tight">{post.title}</h4>
              <p className="text-xs text-gray-500 leading-relaxed uppercase tracking-tighter">{post.excerpt}</p>
              <div className="mt-4 inline-flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-white group-hover:text-blue-500 transition-colors">
                Read Full Insight <Zap size={12} className="fill-current" />
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}

function WriteForUsSection() {
  return (
    <section id="write-for-us" className="py-24 bg-[#141414] border-y border-white/5 relative overflow-hidden">
      <div className="absolute left-0 bottom-0 opacity-5 -ml-20 -mb-20 pointer-events-none">
        <Monitor size={400} />
      </div>
      <div className="mx-auto max-w-7xl px-6 relative">
        <div className="max-w-3xl">
          <h2 className="text-xs font-black uppercase tracking-[0.3em] text-blue-500 mb-6">Expert Contributions</h2>
          <h3 className="text-3xl font-light tracking-tight md:text-4xl mb-8">Write For <span className="italic-serif-header">Net & Box LLC</span></h3>
          <p className="text-sm text-gray-400 leading-relaxed mb-10">
            Are you a telecommunications expert, tech enthusiast, or industry analyst? We are seeking high-quality guest contributions focused on cable technology, broadband infrastructure, and smart home innovations. Join our network of authoritative voices and reach thousands of monthly readers.
          </p>
          
          <div className="grid gap-6 md:grid-cols-2 mb-12">
            {[
              { t: 'Lead generation', d: 'Connect with a massive nationwide audience.' },
              { t: 'Domain Authority', d: 'Build your profile as a JNA-verified expert.' },
              { t: 'Brand Exposure', d: 'Showcase your insights on our premier platform.' },
              { t: 'Network Growth', d: 'Join the JNA Reseller community ecosystem.' }
            ].map((benefit, i) => (
              <div key={i} className="flex gap-4">
                <div className="h-2 w-2 rounded-full bg-blue-600 mt-1.5 shrink-0" />
                <div>
                  <div className="text-xs font-black uppercase text-white mb-1">{benefit.t}</div>
                  <p className="text-[10px] text-gray-500 uppercase">{benefit.d}</p>
                </div>
              </div>
            ))}
          </div>

          <a 
            href="#contact" 
            className="inline-block bg-white text-black px-8 py-4 text-xs font-black uppercase tracking-widest hover:bg-blue-600 hover:text-white transition-all rounded"
          >
            Submit Proposal
          </a>
        </div>
      </div>
    </section>
  );
}

function FAQ() {
  const faqs = [
    { q: "How do I start a new JNA Authorized connection?", a: "Begin by selecting your preferred provider from our rate explorer. Our certified technicians will handle the infrastructure setup and hardware synchronization." },
    { q: "What cable providers are available in Riverside, CA?", a: "We support major providers including Spectrum, Xfinity, COX, and Frontier, alongside specialized JNA Mobility wireless solutions." },
    { q: "Can I bundle high-speed internet with my TV package?", a: "Yes, we specialize in optimized bundles that combine high-speed fiber or broadband with premium 4K UHD cable packages for maximum savings." },
    { q: "What is the benefit of using an Authorized Reseller?", a: "Authorized resellers like Net & Box LLC provide personalized technical audits, local support, and access to exclusive rate schedules often unavailable through direct channels." }
  ];

  return (
    <section className="py-24 bg-[#0a0a0a] border-t border-white/5">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mb-16">
          <h2 className="text-xs font-black uppercase tracking-[0.3em] text-blue-500 mb-4">Support & FAQ</h2>
          <h3 className="text-3xl font-light tracking-tight md:text-5xl">Common Inquiries</h3>
        </div>
        <div className="grid gap-6 md:grid-cols-2">
          {faqs.map((faq, i) => (
            <div key={i} className="p-8 border border-white/5 bg-[#141414] rounded-lg">
              <h4 className="text-sm font-bold uppercase tracking-widest text-white mb-4 text-blue-500">{faq.q}</h4>
              <p className="text-xs text-gray-500 leading-relaxed uppercase">{faq.a}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Contact() {
  return (
    <section id="contact" className="py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-6">
        <div className="grid gap-16 lg:grid-cols-12 lg:items-start">
          <div className="lg:col-span-5">
            <h2 className="text-xs font-black uppercase tracking-[0.3em] text-blue-500 mb-6">Contact</h2>
            <h3 className="text-4xl font-light tracking-tight mb-8">Get Assistance</h3>
            <div className="space-y-10">
              <div className="group">
                <div className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-600 mb-2">Voice Assistance</div>
                <a href="tel:8884092279" className="text-2xl font-light hover:text-blue-500 transition-colors">(888) 409-2279</a>
              </div>
              <div className="group">
                <div className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-600 mb-2">Electronic Mail</div>
                <a href="mailto:info@netpayment.online" className="text-xl font-light hover:text-blue-500 transition-colors lowercase">info@netpayment.online</a>
              </div>
              <div className="group">
                <div className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-600 mb-2">Central Location</div>
                <address className="text-sm font-light text-gray-400 not-italic leading-relaxed">
                  6769 Palm Ct #139, <br />
                  Riverside, CA 92506, US
                </address>
              </div>
            </div>
          </div>
          <div className="lg:col-span-7 bg-[#141414] border border-white/10 p-10 rounded-lg">
            <form id="contact-form" className="space-y-6" onSubmit={(e) => e.preventDefault()}>
              <div className="grid gap-6 md:grid-cols-2">
                <div className="space-y-2">
                  <label htmlFor="name" className="text-[10px] font-black uppercase tracking-widest text-gray-500">Full Name</label>
                  <input id="name" type="text" className="w-full border border-white/10 bg-[#0a0a0a] px-4 py-4 text-xs font-medium focus:outline-none focus:border-blue-500 transition-all rounded" placeholder="Required" />
                </div>
                <div className="space-y-2">
                  <label htmlFor="email" className="text-[10px] font-black uppercase tracking-widest text-gray-500">Email Address</label>
                  <input id="email" type="email" className="w-full border border-white/10 bg-[#0a0a0a] px-4 py-4 text-xs font-medium focus:outline-none focus:border-blue-500 transition-all rounded" placeholder="Required" />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-gray-500">Select Service Inquiry</label>
                <div className="grid grid-cols-2 gap-3">
                  {['New Setup', 'Upgrades', 'Channels', 'Support'].map(opt => (
                    <button key={opt} type="button" className="py-3 px-4 border border-white/5 bg-[#0a0a0a] text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:border-blue-500 hover:text-white rounded">
                      {opt}
                    </button>
                  ))}
                </div>
              </div>
              <div className="space-y-2">
                <label htmlFor="message" className="text-[10px] font-black uppercase tracking-widest text-gray-500">Message Context</label>
                <textarea id="message" rows={4} className="w-full border border-white/10 bg-[#0a0a0a] px-4 py-4 text-xs font-medium focus:outline-none focus:border-blue-500 transition-all rounded resize-none" placeholder="Provide details..."></textarea>
              </div>
              <button id="submit-button" type="submit" className="w-full bg-white py-5 text-xs font-black uppercase tracking-widest text-black transition-all hover:bg-blue-500 hover:text-white rounded">
                Transmit Request
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}

function Newsletter() {
  return (
    <section className="py-20 bg-blue-600">
      <div className="mx-auto max-w-7xl px-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-10">
          <div className="max-w-md">
            <h3 className="text-2xl font-bold text-white mb-2">Join the JNA Professional Network</h3>
            <p className="text-white/70 text-xs uppercase font-black tracking-widest">Get the latest rate schedules, bundle leaks, and technical insights weekly.</p>
          </div>
          <form className="flex w-full max-w-md gap-2" onSubmit={(e) => e.preventDefault()}>
            <input 
              type="email" 
              placeholder="YOUR@PROFESSIONAL.EMAIL" 
              className="flex-1 bg-white/10 border border-white/20 rounded px-4 py-3 text-xs font-black uppercase text-white placeholder:text-white/40 focus:outline-none focus:bg-white/20 transition-all"
            />
            <button className="bg-white text-black px-6 py-3 rounded text-[10px] font-black uppercase tracking-widest hover:bg-black hover:text-white transition-all shadow-xl">
              Subscribe
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}

function Footer({ onLegalClick }: { onLegalClick: (type: string) => void }) {
  return (
    <footer id="footer" className="border-t border-white/10 bg-[#0a0a0a] py-16">
      <div className="mx-auto max-w-7xl px-6">
        <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-4 mb-20">
          <div className="col-span-1 lg:col-span-1">
            <div className="flex items-center gap-3 mb-6">
              <div className="flex h-8 w-8 items-center justify-center rounded bg-blue-600 text-white shadow-lg shadow-blue-900/40">
                <Tv size={18} />
              </div>
              <span className="text-sm font-bold tracking-tighter">
                NET & BOX <span className="text-blue-500 uppercase">LLC</span>
              </span>
            </div>
            <p className="text-xs font-bold text-blue-500 uppercase tracking-widest mb-4">
              Authorized Resident Dealer
            </p>
            <p className="text-[11px] font-medium leading-relaxed uppercase tracking-tighter text-gray-500 mb-6">
              Official JNA Reseller serving all 50 US states. Dedicated to technical excellence in broadband and TV infrastructure deployment.
            </p>
          </div>
          
          <div>
            <p className="text-[10px] text-gray-600 uppercase mb-4 font-black">Resources</p>
            <nav className="flex flex-col gap-3">
              <button onClick={() => onLegalClick('privacy')} className="text-[10px] font-bold uppercase tracking-widest text-white hover:text-blue-500 transition-colors text-left font-sans font-bold">Privacy Policy</button>
              <button onClick={() => onLegalClick('terms')} className="text-[10px] font-bold uppercase tracking-widest text-white hover:text-blue-500 transition-colors text-left font-sans font-bold">Terms of Service</button>
              <button onClick={() => onLegalClick('refund')} className="text-[10px] font-bold uppercase tracking-widest text-white hover:text-blue-500 transition-colors text-left font-sans font-bold">Refund Policy</button>
              <a href="#write-for-us" className="text-[10px] font-bold uppercase tracking-widest text-white hover:text-blue-500 transition-colors">Write For Us</a>
            </nav>
          </div>

          <div>
            <p className="text-[10px] text-gray-600 uppercase mb-4 font-black">Support Channels</p>
            <nav className="flex flex-col gap-3">
              <a href="#contact" className="text-[10px] font-bold uppercase tracking-widest text-white hover:text-blue-500 transition-colors">Technical Helpdesk</a>
              <a href="#blog" className="text-[10px] font-bold uppercase tracking-widest text-white hover:text-blue-500 transition-colors">Insights Center</a>
              <a href="#packages" className="text-[10px] font-bold uppercase tracking-widest text-white hover:text-blue-500 transition-colors">Rate Explorer</a>
            </nav>
          </div>

          <div>
            <p className="text-[10px] text-gray-600 uppercase mb-4 font-black">Headquarters</p>
            <div className="flex flex-col gap-3">
              <div className="flex items-center gap-3 text-[10px] font-bold uppercase text-gray-400">
                <MapPin size={14} className="text-blue-500" /> Riverside, California
              </div>
              <div className="flex items-center gap-3 text-[10px] font-bold uppercase text-gray-400">
                <Mail size={14} className="text-blue-500" /> contact@netboxllc.com
              </div>
              <div className="bg-white/5 p-4 rounded border border-white/5">
                <div className="text-[9px] font-black uppercase text-blue-500 mb-1">Business Hours</div>
                <div className="text-[10px] font-bold uppercase text-white">Mon - Sun: 00:00 - 23:59</div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="flex flex-col md:flex-row items-center justify-between border-t border-white/5 pt-8 gap-6">
          <div className="text-[9px] font-black uppercase tracking-[0.2em] text-gray-600">
            © {new Date().getFullYear()} Bill Payment Net & Box LLC. Licensed Nationwide Dealer.
          </div>
          <div className="flex items-center gap-6">
            <span className="h-1 w-1 rounded-full bg-blue-500" />
            <span className="text-[10px] font-black uppercase text-white tracking-widest">JNA Agent Program ID: VERIFIED</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
